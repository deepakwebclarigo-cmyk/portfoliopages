# Clarigo Portfolio

A responsive Next.js portfolio using TypeScript, Three.js / React Three Fiber, GSAP ScrollTrigger, Framer Motion, and Lucide.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Pages and interaction

- Portfolio listing at `/` with search, project-type filters, and animated project cards
- Static project pages at `/portfolio/[slug]` for the verified web and mobile inventory
- Reusable project previews and centralized project records in `lib/projects.ts`
- Three.js orbital hero artwork, GSAP section reveals, and Framer Motion card interactions
- Responsive navigation, reduced-motion support, optimized remote project images, and page metadata

The public portfolio listing verifies 19 web projects and 28 unique mobile projects. The linked case-study pages contain mostly placeholder text and do not provide reliable project-by-project challenges, feature lists, technology stacks, process details, UI screenshot sets, or outcomes. Those fields are therefore modeled as optional project data and the detail pages explicitly identify unavailable source material rather than presenting invented claims. Add verified content to each record's `details` field in `lib/projects.ts` as it becomes available.

Project preview assets and source archive links currently use the existing Clarigo portfolio host. If those assets are migrated, update the URL and image host configuration in `lib/projects.ts` and `next.config.ts`.
