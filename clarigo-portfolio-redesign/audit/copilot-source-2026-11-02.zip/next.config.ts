import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'clarigo-voluble-youtiao-e0781d.netlify.app',
      },
    ],
  },
};

export default nextConfig;
