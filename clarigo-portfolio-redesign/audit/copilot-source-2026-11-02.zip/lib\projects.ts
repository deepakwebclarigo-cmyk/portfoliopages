export type ProjectDetails = {
  overview?: string;
  challenge?: string;
  solution?: string;
  features?: string[];
  screenshots?: string[];
  technologies?: string[];
  process?: string[];
  results?: string;
};

export type Project = {
  slug: string;
  name: string;
  kind: 'web' | 'mobile';
  category: 'Web & web apps' | 'Mobile apps';
  image: string;
  legacy: string;
  summary: string;
  accent: string;
  details?: ProjectDetails;
};

const host = 'https://clarigo-voluble-youtiao-e0781d.netlify.app';
type ProjectRow = [name: string, image: string, page: string];

const webRows: ProjectRow[] = [
  ['LivSocial', 'LivSocial.png', 'livSocial-web.html'],
  ['StreamDataX', 'StreamDataX.png', 'StreamDataX-web.html'],
  ['Little-Butterflies', 'Little-Butterflies-Poster.png', 'Little-Butterflies-n.html'],
  ['TukeeConnect', 'TukeeConnect.png', 'TukeeConnect-web.html'],
  ['Beliri', 'Beliri.png', 'Beliri-web-n.html'],
  ['Printlific', 'Printlific.png', 'Printlific.html'],
  ['Nerdrabbit', 'nerdrabbit.png', 'Nerdrabbit-web-n.html'],
  ['Parachute', 'parachute.png', 'parachute-web-n.html'],
  ['Glocal Expert', 'global.png', 'glocal-expert-web.html'],
  ['Mercury Mailroom', 'mercury.jpg', 'mercury-web.html'],
  ['Umeed', 'umeed.png', 'ummed-web-n.html'],
  ['Alum-connect', 'Alum-connect.png', 'alum-connect-web.html'],
  ['Kegelklock', 'Kegelklock.png', 'kegelklock-web.html'],
  ['BR-tennis', 'BR-tennis.png', 'BR-tennis-web-n.html'],
  ['Network Capital', 'network-capital.jpg', 'network-capital-web.html'],
  ['Whizara', 'whizara.png', 'whizara-n.html'],
  ['Es-Platform', 'es-platform.png', 'es-platform-n.html'],
  ['Been There', 'Been_there.png', 'been-there-n.html'],
  ['Lead Management', 'Lead.png', 'Lead-Management.html'],
];

const mobileRows: ProjectRow[] = [
  ['LivSocial', 'LivSocial-app.png', 'livsocial.html'],
  ['Simply Recruited', 'Simply_Recruited_App.png', 'SimplyRecruited.html'],
  ['Infinote', 'Infinote_App.png', 'infinote.html'],
  ['Silasync', 'Silasync_App.png', 'Silasync.html'],
  ['Digital Habit Tracker', 'Digital_Habit_Tracker_App.png', 'digital-habit-tracker.html'],
  ['TukeeConnect', 'TukeeConnect_App.png', 'TukeeConnect.html'],
  ['Pace of Play', 'Pace_of_Play_App.png', 'pop.html'],
  ['Qcop App', 'Qcop_App.png', 'qcop.html'],
  ['Little Butterflies', 'Little_Butterflies_App.png', 'Little-Butterflies.html'],
  ['Case Managment ASE', 'Case_Managment_ASE_App.png', 'Case-Management.html'],
  ['Printlific', 'Printlific_App.png', 'Printlific.html'],
  ['Law Legend', 'Law_Legend_App.png', 'law-Legends.html'],
  ['Racepace', 'Racepace_App.png', 'racepace-app.html'],
  ['Been There', 'Been_There_App.png', 'Been-There.html'],
  ['One Pantry', 'ONE_PANTRY_App.png', 'one-pantry.html'],
  ['EscapeTheHOA', 'EscapeTheHOA_App.png', 'Escape.html'],
  ['Dateflow', 'Dateflow_App.png', 'dateflow-n.html'],
  ['Meravyaah', 'meravyaah_App.png', 'meravyaah.html'],
  ['Beliri', 'Belleri.png', 'beliri-n.html'],
  ['Fynmate', 'Fynmate.png', 'fynmate-app.html'],
  ['Street Sheets', 'streetsheets.png', 'street-sheets-app-1.html'],
  ['Ummed', 'ummid.png', 'umeed-n.html'],
  ['Bubble', 'Bubble.png', 'bubble-n.html'],
  ['Kegalklock', 'kegalklock.png', 'kegalklock-app.html'],
  ['Gymbet', 'Gymbet.png', 'gymbet-app.html'],
  ['GoBroker', 'GoBroker-app.png', 'GoBroker-app.html'],
  ['Heartsync', 'heartsync.png', 'heartsync.html'],
  ['Suppliment Management', 'suppliment.png', 'gymbet-app.html'],
];

const accents = ['#ffd9dc', '#dce7ff', '#e9e2ff', '#d7f0eb', '#ffe8d0', '#e6ebf7'];

function createProjects(rows: ProjectRow[], kind: Project['kind']): Project[] {
  const folder = kind === 'web' ? 'website-projects' : 'applications-projects';
  const category = kind === 'web' ? 'Web & web apps' : 'Mobile apps';
  return rows.map(([name, image, page], index) => {
    const baseSlug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/-$/g, '');
    return {
      name,
      category,
      image: `${host}/assets/images/projects/${folder}/${image}`,
      legacy: `${host}/landing%20page/${page}`,
      summary: `${category} project featured in Clarigo's public portfolio.`,
      accent: accents[index % accents.length],
      kind,
      slug: kind === 'mobile' ? `app-${baseSlug}` : baseSlug,
    };
  });
}

export const webProjects = createProjects(webRows, 'web');
export const mobileProjects = createProjects(mobileRows, 'mobile');
export const projects = [...webProjects, ...mobileProjects];
