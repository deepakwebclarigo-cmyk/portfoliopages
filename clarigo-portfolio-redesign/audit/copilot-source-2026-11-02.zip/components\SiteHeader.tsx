import Link from 'next/link';
import { ArrowUpRight, Menu } from 'lucide-react';

const links = (
  <>
    <a href="https://clarigoinfotech.com/">Home</a>
    <a href="https://clarigoinfotech.com/services">Services</a>
    <Link href="/#portfolio">Work</Link>
    <a href="https://clarigoinfotech.com/contact">Contact</a>
  </>
);

export default function SiteHeader() {
  return (
    <header className="siteHeader">
      <div className="shell siteNav">
        <Link href="/" className="brand" aria-label="Clarigo portfolio home">
          <img src="https://clarigoinfotech.com/logo.png" alt="Clarigo Infotech" width="136" height="42" />
        </Link>
        <nav className="desktopNav" aria-label="Main navigation">{links}</nav>
        <a className="navCta" href="https://clarigoinfotech.com/contact" aria-label="Book a free AI consultation">
          Book Free AI Consultation <ArrowUpRight size={15} />
        </a>
        <details className="mobileNav">
          <summary aria-label="Open navigation"><Menu size={22} /></summary>
          <nav aria-label="Mobile navigation">{links}</nav>
        </details>
      </div>
    </header>
  );
}
