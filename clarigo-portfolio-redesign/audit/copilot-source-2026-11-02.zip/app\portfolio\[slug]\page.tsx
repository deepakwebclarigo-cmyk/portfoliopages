import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, ArrowRight, ArrowUpRight, CircleHelp } from 'lucide-react';
import SiteHeader from '../../../components/SiteHeader';
import ProjectVisual from '../../../components/ProjectVisual';
import { mobileProjects, projects, webProjects } from '../../../lib/projects';

type DetailProps = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return projects.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: DetailProps): Promise<Metadata> {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  if (!project) return { title: 'Project not found' };
  return {
    title: project.name,
    description: project.summary,
    openGraph: {
      title: `${project.name} | Selected Work`,
      description: project.summary,
      images: [project.image],
    },
  };
}

function SourceNote({ children }: { children: string }) {
  return (
    <div className="sourceNote">
      <CircleHelp size={18} aria-hidden="true" />
      <p>{children}</p>
    </div>
  );
}

export default async function Detail({ params }: DetailProps) {
  const { slug } = await params;
  const project = projects.find((item) => item.slug === slug);
  if (!project) notFound();

  const projectList = project.kind === 'web' ? webProjects : mobileProjects;
  const index = projectList.indexOf(project);
  const next = projectList[(index + 1) % projectList.length];
  const related = [1, 2, 3].map((offset) => projectList[(index + offset) % projectList.length]);

  return (
    <>
      <SiteHeader />
      <main>
        <section className="caseHero shell">
          <Link className="backLink" href="/#portfolio"><ArrowLeft size={16} /> All projects</Link>
          <div className="caseHeroGrid">
            <div className="caseIntro">
              <div className="eyebrow"><span className="statusDot" /> SELECTED WORK / {project.category.toUpperCase()}</div>
              <h1>{project.name}<span>.</span></h1>
              <p>{project.summary}</p>
              <div className="caseMeta">
                <div><span>PROJECT TYPE</span><strong>{project.category}</strong></div>
                <div><span>PROJECT</span><strong>{String(index + 1).padStart(2, '0')} / {String(projectList.length).padStart(2, '0')}</strong></div>
              </div>
            </div>
            <div className="caseVisual">
              <div className="caseVisualGlow" aria-hidden="true" />
              <ProjectVisual project={project} large priority />
              <span className="visualCaption">PROJECT PREVIEW / PUBLIC PORTFOLIO</span>
            </div>
          </div>
        </section>

        <div className="caseNav shell" aria-label="Case study sections">
          <a href="#overview">Overview</a>
          <a href="#approach">Approach</a>
          <a href="#screens">Screens</a>
          <a href="#technology">Technology</a>
          <a href="#results">Results</a>
        </div>

        <section className="caseSection shell" id="overview" data-reveal>
          <div className="sectionLabel"><span>01</span> PROJECT OVERVIEW</div>
          <div className="caseTwoCol">
            <h2>A project from<br />the Clarigo archive<span>.</span></h2>
            <div className="caseBody">
              <p>{project.summary}</p>
              {project.details?.overview ? <p>{project.details.overview}</p> : (
                <SourceNote>Additional project background is not included in the accessible public portfolio listing.</SourceNote>
              )}
            </div>
          </div>
        </section>

        <section className="caseBand" id="approach" data-reveal>
          <div className="shell">
            <div className="sectionLabel"><span>02</span> CHALLENGE &amp; SOLUTION</div>
            <div className="approachGrid">
              <article>
                <span className="approachNumber">A</span>
                <h2>The challenge</h2>
                {project.details?.challenge ? <p>{project.details.challenge}</p> : <SourceNote>The project challenge was not described in the published source material.</SourceNote>}
              </article>
              <article>
                <span className="approachNumber">B</span>
                <h2>The solution</h2>
                {project.details?.solution ? <p>{project.details.solution}</p> : <SourceNote>Project-specific implementation details were not available in the published source material.</SourceNote>}
              </article>
            </div>
          </div>
        </section>

        <section className="caseSection shell" data-reveal>
          <div className="sectionLabel"><span>03</span> KEY FEATURES</div>
          <div className="featurePanel">
            <div>
              <h2>Made for the<br />details that matter.</h2>
              <p>Feature-level information is shown when it is included in the project source.</p>
            </div>
            {project.details?.features?.length ? (
              <ul className="featureList">{project.details.features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
            ) : (
              <SourceNote>The public archive does not list verified features for this project.</SourceNote>
            )}
          </div>
        </section>

        <section className="screenSection" id="screens" data-reveal>
          <div className="shell">
            <div className="sectionLabel"><span>04</span> UI SCREENS</div>
            <div className="screenHeader">
              <h2>Inside the experience<span>.</span></h2>
              <p>Original portfolio artwork is shown below. Additional UI screenshots are available only where provided in the source archive.</p>
            </div>
            {project.details?.screenshots?.length ? (
              <div className="screensGrid">
                {project.details.screenshots.map((image, screenIndex) => (
                  <figure key={image}><img src={image} alt={`${project.name} interface screen ${screenIndex + 1}`} loading="lazy" /><figcaption>SCREEN {String(screenIndex + 1).padStart(2, '0')}</figcaption></figure>
                ))}
              </div>
            ) : (
              <div className="archiveArtwork">
                <ProjectVisual project={project} large />
                <div className="artworkCaption">
                  <span>VERIFIED PROJECT ARTWORK</span>
                  <a href={project.legacy} target="_blank" rel="noreferrer">Open original project archive <ArrowUpRight size={16} /></a>
                </div>
              </div>
            )}
          </div>
        </section>

        <section className="caseSection shell" id="technology" data-reveal>
          <div className="sectionLabel"><span>05</span> TECHNOLOGY &amp; DEVELOPMENT</div>
          <div className="caseTwoCol techGrid">
            <div>
              <h2>The tools behind<br />the build<span>.</span></h2>
              <p>Stack and delivery details are included when the public case-study source identifies them.</p>
            </div>
            <div className="techColumn">
              <h3>Technology stack</h3>
              {project.details?.technologies?.length ? (
                <div className="techTags">{project.details.technologies.map((technology) => <span key={technology}>{technology}</span>)}</div>
              ) : (
                <SourceNote>A project-specific technology stack was not published. We have not inferred one from Clarigo's broader capabilities.</SourceNote>
              )}
              <h3>Development process</h3>
              {project.details?.process?.length ? (
                <ol className="processList">{project.details.process.map((step, stepIndex) => <li key={step}><span>{String(stepIndex + 1).padStart(2, '0')}</span>{step}</li>)}</ol>
              ) : (
                <SourceNote>A project-specific development process was not published in the available archive.</SourceNote>
              )}
            </div>
          </div>
        </section>

        <section className="resultsSection" id="results" data-reveal>
          <div className="shell resultsInner">
            <div className="sectionLabel"><span>06</span> OUTCOMES</div>
            <h2>Results, without<br />the guesswork<span>.</span></h2>
            {project.details?.results ? <p>{project.details.results}</p> : (
              <SourceNote>No project-specific results or performance metrics were published in the accessible source. We do not invent outcome figures.</SourceNote>
            )}
          </div>
        </section>

        <section className="relatedSection shell" data-reveal>
          <div className="relatedHeading">
            <div><div className="eyebrow">KEEP EXPLORING</div><h2>Related projects<span>.</span></h2></div>
            <Link href="/#portfolio">View all work <ArrowUpRight size={16} /></Link>
          </div>
          <div className="relatedGrid">
            {related.map((item) => (
              <Link href={`/portfolio/${item.slug}`} className="relatedCard" key={item.slug}>
                <div className="relatedImage"><ProjectVisual project={item} /></div>
                <span>{item.category}</span><strong>{item.name}</strong><ArrowRight size={17} />
              </Link>
            ))}
          </div>
        </section>

        <section className="caseCta">
          <div className="shell caseCtaInner" data-reveal>
            <div><div className="eyebrow">HAVE A PROJECT IN MIND?</div><h2>Let&apos;s make your<br /><span>next idea real.</span></h2></div>
            <a className="buttonPrimary" href="https://clarigoinfotech.com/contact">Book a free consultation <ArrowUpRight size={17} /></a>
          </div>
        </section>
      </main>
      <footer className="siteFooter shell">
        <a href="https://clarigoinfotech.com/" className="footerBrand"><img src="https://clarigoinfotech.com/logo.png" alt="Clarigo Infotech" width="136" height="42" /></a>
        <span>AI-first engineering · 10+ years of delivery</span>
        <span>© {new Date().getFullYear()} Clarigo Infotech</span>
      </footer>
    </>
  );
}
