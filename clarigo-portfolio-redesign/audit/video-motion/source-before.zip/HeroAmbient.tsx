'use client';

import { useEffect, useRef } from 'react';
import type { CSSProperties } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Fixed positions keep server markup deterministic. Nothing intercepts a link or pointer.
const particles = [[20, 24, 3], [74, 21, 2], [87, 49, 3], [65, 76, 2], [26, 72, 2], [44, 13, 2], [48, 59, 3]];

export default function HeroAmbient() {
  const element = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = element.current, hero = root?.closest<HTMLElement>('.heroSection');
    if (!root || !hero) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add({ all: 'all', reduce: '(prefers-reduced-motion: reduce)', compact: '(max-width: 700px)', pointer: '(min-width: 1001px) and (hover: hover) and (pointer: fine)' }, context => {
      if (context.conditions?.reduce || context.conditions?.compact) {
        root.dataset.ambientState = 'static';
        root.dataset.pointerDepth = 'false';
        return;
      }
      const stage = root.querySelector<HTMLElement>('.heroAmbientStage')!;
      const initialBounds = hero.getBoundingClientRect();
      let bounds = initialBounds, documentTop = initialBounds.top + scrollY, visible = initialBounds.bottom > 0 && initialBounds.top < innerHeight, active = true;
      const loops: gsap.core.Tween[] = [];
      loops.push(gsap.fromTo(root.querySelector('.heroBlobRose'), { x: -10, y: 8, rotation: -4, scale: .98 }, { x: 14, y: -12, rotation: 4, scale: 1.04, duration: 14, repeat: -1, yoyo: true, ease: 'sine.inOut', paused: true }));
      loops.push(gsap.fromTo(root.querySelector('.heroBlobLavender'), { x: 8, y: -8, rotation: 3 }, { x: -14, y: 14, rotation: -3, duration: 18, repeat: -1, yoyo: true, ease: 'sine.inOut', paused: true }));
      loops.push(gsap.fromTo(root.querySelector('.heroBlobLight'), { x: 0, y: 5, scale: .98 }, { x: -8, y: -10, scale: 1.04, duration: 12, repeat: -1, yoyo: true, ease: 'sine.inOut', paused: true }));
      root.querySelectorAll('.heroParticle').forEach((particle, index) => {
        loops.push(gsap.fromTo(particle, { y: 0, opacity: .16 }, { y: -12 - index % 3 * 3, opacity: .42, duration: 5 + index % 4, delay: index * .16, repeat: -1, yoyo: true, ease: 'sine.inOut', paused: true }));
      });
      // Scroll depth and pointer depth live on separate wrappers, never on the text.
      gsap.to(root.querySelector('.heroAmbientScroll'), { y: 36, ease: 'none', scrollTrigger: { trigger: hero, start: 'top top', end: 'bottom top', scrub: .8 } });
      const arrival = gsap.fromTo(root.querySelector('.heroAmbientArrival'), { opacity: 0 }, { opacity: 1, duration: 1.4, delay: .18, ease: 'power2.out', paused: true });
      const pointer = Boolean(context.conditions?.pointer);
      root.dataset.pointerDepth = String(pointer);
      const moveX = gsap.quickTo(stage, 'x', { duration: .9, ease: 'power3.out' });
      const moveY = gsap.quickTo(stage, 'y', { duration: .9, ease: 'power3.out' });
      const rotateX = gsap.quickTo(stage, 'rotationX', { duration: 1.1, ease: 'power3.out' });
      const rotateY = gsap.quickTo(stage, 'rotationY', { duration: 1.1, ease: 'power3.out' });
      const resetPointer = () => { moveX(0); moveY(0); rotateX(0); rotateY(0); };
      const settlePointer = () => {
        [moveX, moveY, rotateX, rotateY].forEach(move => move.tween.pause());
        gsap.set(stage, { x: 0, y: 0, rotationX: 0, rotationY: 0 });
      };
      const refreshBounds = () => { bounds = hero.getBoundingClientRect(); documentTop = bounds.top + scrollY; };
      const move = (event: PointerEvent) => {
        if (!visible || !active || document.hidden || event.pointerType !== 'mouse') return;
        const x = gsap.utils.clamp(-1, 1, (event.clientX - bounds.left) / bounds.width * 2 - 1);
        const y = gsap.utils.clamp(-1, 1, (event.clientY + scrollY - documentTop) / bounds.height * 2 - 1);
        moveX(x * 14); moveY(y * 10); rotateX(-y * 2); rotateY(x * 2.5);
      };
      const sync = () => {
        const running = visible && active && !document.hidden;
        loops.forEach(tween => running ? tween.play() : tween.pause());
        if (running) arrival.play(); else { arrival.pause(); settlePointer(); }
        root.dataset.ambientState = running ? 'running' : 'paused';
      };
      const observer = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; sync(); });
      observer.observe(hero);
      const blur = () => { active = false; sync(); };
      const focus = () => { active = true; refreshBounds(); sync(); };
      document.addEventListener('visibilitychange', sync);
      window.addEventListener('blur', blur); window.addEventListener('focus', focus);
      window.addEventListener('pagehide', blur); window.addEventListener('pageshow', focus);
      window.addEventListener('resize', refreshBounds, { passive: true });
      if (pointer) {
        hero.addEventListener('pointerenter', refreshBounds);
        hero.addEventListener('pointermove', move);
        hero.addEventListener('pointerleave', resetPointer);
        hero.addEventListener('pointercancel', resetPointer);
      }
      sync();
      return () => {
        observer.disconnect();
        document.removeEventListener('visibilitychange', sync);
        window.removeEventListener('blur', blur); window.removeEventListener('focus', focus);
        window.removeEventListener('pagehide', blur); window.removeEventListener('pageshow', focus);
        window.removeEventListener('resize', refreshBounds);
        hero.removeEventListener('pointerenter', refreshBounds); hero.removeEventListener('pointermove', move);
        hero.removeEventListener('pointerleave', resetPointer); hero.removeEventListener('pointercancel', resetPointer);
      };
    });
    return () => { media.revert(); delete root.dataset.ambientState; delete root.dataset.pointerDepth; };
  }, []);

  return <div ref={element} className="heroAmbient" aria-hidden="true">
    <div className="heroAmbientScroll"><div className="heroAmbientArrival"><div className="heroAmbientStage">
      <i className="heroBlob heroBlobLavender" /><i className="heroBlob heroBlobRose" /><i className="heroBlob heroBlobLight" />
      {particles.map(([x, y, size], index) => <i className="heroParticle" key={index} style={{ left: `${x}%`, top: `${y}%`, '--particle-size': `${size}px` } as CSSProperties} />)}
    </div></div></div>
  </div>;
}
