import { heroShowcaseAssets } from '../lib/hero-showcase-data';

// A static accessible fallback while WebGL loads or when motion/graphics are disabled.
export default function HeroShowcaseFallback() {
  return <div className="heroShowcaseFallback">
    <div className="showcaseFallbackBrowser"><span>Beliri / Web project</span><svg viewBox="114 230 1266 850" aria-hidden="true"><image href={heroShowcaseAssets[0].src} width="1495" height="2200" /></svg></div>
    <div className="showcaseFallbackPhone"><svg viewBox="23 20 330 714" aria-hidden="true"><image href={heroShowcaseAssets[2].src} width="376" height="813" /></svg></div>
    <span className="showcaseFallbackLabel">Web + Mobile</span>
  </div>;
}
