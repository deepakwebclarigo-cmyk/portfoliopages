import * as THREE from 'three';
import { heroShowcaseAssets } from './hero-showcase-data';

function shape(width: number, height: number, radius: number) {
  const x = -width / 2, y = -height / 2, r = Math.min(radius, width / 2, height / 2), s = new THREE.Shape();
  s.moveTo(x+r,y); s.lineTo(x+width-r,y); s.quadraticCurveTo(x+width,y,x+width,y+r); s.lineTo(x+width,y+height-r);
  s.quadraticCurveTo(x+width,y+height,x+width-r,y+height); s.lineTo(x+r,y+height); s.quadraticCurveTo(x,y+height,x,y+height-r);
  s.lineTo(x,y+r); s.quadraticCurveTo(x,y,x+r,y); return s;
}
function bodyGeometry(width: number, height: number, depth: number, radius: number) {
  const geometry = new THREE.ExtrudeGeometry(shape(width,height,radius), { depth, bevelEnabled:true, bevelSize:.012, bevelThickness:.012, bevelSegments:3, curveSegments:8, steps:1 });
  geometry.translate(0,0,-depth/2); return geometry;
}
function screenGeometry(width: number, height: number, radius: number) {
  const geometry = new THREE.ShapeGeometry(shape(width,height,radius),8), positions=geometry.attributes.position, uv=geometry.attributes.uv;
  for(let index=0;index<positions.count;index++)uv.setXY(index,(positions.getX(index)+width/2)/width,(positions.getY(index)+height/2)/height);
  return geometry;
}

export function createHeroShowcase(renderer: THREE.WebGLRenderer) {
  const group = new THREE.Group(), picks: THREE.Mesh[] = [], geometries: THREE.BufferGeometry[] = [], materials: THREE.Material[] = [], textures: THREE.Texture[] = [];
  const white = new THREE.MeshPhysicalMaterial({ color:'#ffffff', roughness:.27, metalness:.08, clearcoat:.8, clearcoatRoughness:.2 });
  const edge = new THREE.MeshPhysicalMaterial({ color:'#f4415a', roughness:.26, metalness:.08, clearcoat:.9 });
  const dark = new THREE.MeshStandardMaterial({color:'#34343e',roughness:.3,metalness:.35});
  materials.push(white,edge,dark);
  const loader = new THREE.TextureLoader(), pending: Promise<unknown>[] = [];
  let disposed = false;
  function addMesh(parent: THREE.Group, geometry: THREE.BufferGeometry, material: THREE.Material, index: number, z=0) {
    geometries.push(geometry); const mesh = new THREE.Mesh(geometry,material); mesh.position.z=z;mesh.castShadow=true;mesh.receiveShadow=true;
    mesh.userData.showcaseIndex=index; parent.add(mesh);picks.push(mesh);return mesh;
  }
  function label(text: string, width: number, height: number, color='#696d7b', background='transparent') {
    const canvas=document.createElement('canvas');canvas.width=640;canvas.height=Math.round(640*height/width);
    const context=canvas.getContext('2d')!;context.fillStyle=background;context.fillRect(0,0,canvas.width,canvas.height);
    context.fillStyle=color;context.font='500 '+Math.round(canvas.height*.47)+'px Geist, Arial, sans-serif';context.textBaseline='middle';context.fillText(text,8,canvas.height*.52);
    const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;textures.push(texture);
    const material=new THREE.MeshBasicMaterial({map:texture,transparent:true,toneMapped:false,depthWrite:false});materials.push(material);
    return {geometry:new THREE.PlaneGeometry(width,height),material};
  }
  function artwork(parent: THREE.Group, assetIndex: number, width: number, height: number, y: number, z: number, radius: number, cover: boolean) {
    const asset=heroShowcaseAssets[assetIndex];
    const material = new THREE.MeshBasicMaterial({color:'white',toneMapped:false});materials.push(material);
    addMesh(parent,screenGeometry(width,height,radius),material,assetIndex,z).position.y=y;
    pending.push(loader.loadAsync(asset.src).then(texture=>{
      if(disposed){texture.dispose();return;}
      textures.push(texture);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());
      const crop=asset.crop;let visibleWidth:number=crop.width,visibleHeight:number=crop.height;
      if(cover){if(crop.width/crop.height>width/height)visibleWidth=crop.height*width/height;else visibleHeight=crop.width*height/width;}
      texture.repeat.set(visibleWidth/asset.width,visibleHeight/asset.height);
      texture.offset.set((crop.x+(crop.width-visibleWidth)/2)/asset.width,1-(crop.y+visibleHeight)/asset.height);
      material.map=texture;material.needsUpdate=true;
    }));
  }
  const items: { object: THREE.Group; position: THREE.Vector3; rotation: THREE.Euler }[] = [];
  function item(position: [number,number,number], rotation: [number,number,number]) {
    const object=new THREE.Group();object.position.set(...position);object.rotation.set(...rotation);group.add(object);
    items.push({object,position:object.position.clone(),rotation:object.rotation.clone()});return object;
  }
  function browser(index: number, width: number, height: number, position: [number,number,number], rotation: [number,number,number]) {
    const object=item(position,rotation), depth=.09;
    addMesh(object,bodyGeometry(width,height,depth,.12),white,index);
    artwork(object,index,width-.14,height-.36,-.10,depth/2+.014,.045,true);
    for(let dot=0;dot<3;dot++) { const mesh=addMesh(object,new THREE.SphereGeometry(.021,12,8),edge,index,.065);mesh.position.set(-width/2+.16+dot*.075,height/2-.125,.065); }
    const title=label(heroShowcaseAssets[index].name,width*.45,.15);addMesh(object,title.geometry,title.material,index,.066).position.set(.1,height/2-.127,.066);
    return object;
  }
  browser(0,3.35,2.4,[-.27,.12,.02],[-.045,-.13,-.045]);
  browser(1,2.35,1.35,[-.73,1.03,-.65],[.03,.11,.075]);
  const phone=item([1.35,-.25,.7],[.015,.12,.08]);
  addMesh(phone,bodyGeometry(1.02,2.25,.15,.16),edge,2,-.035);
  addMesh(phone,bodyGeometry(.995,2.225,.14,.15),white,2);
  addMesh(phone,bodyGeometry(.87,1.94,.022,.115),dark,2,.083);
  artwork(phone,2,.825,1.785,-.015,.125,.085,false);
  const side=addMesh(phone,new THREE.BoxGeometry(.025,.23,.045),edge,2);side.position.set(.51,.33,0);
  const card=item([-.83,-1.23,.58],[.035,.08,-.06]);
  addMesh(card,bodyGeometry(1.85,.57,.075,.11),white,3);
  const icon=addMesh(card,bodyGeometry(.25,.22,.035,.04),edge,3,.065);icon.position.x=-.62;
  const title=label('Web + Mobile',1.1,.18,'#262833');addMesh(card,title.geometry,title.material,3,.06).position.set(.13,.015,.06);
  // A small bevelled accent, rather than an invented UI or a decorative wireframe.
  const accent=item([1.25,1.22,-.25],[.1,.25,-.22]);
  addMesh(accent,bodyGeometry(.48,.14,.075,.06),edge,4);
  const shadowCanvas=document.createElement('canvas');shadowCanvas.width=256;shadowCanvas.height=64;
  const shadowContext=shadowCanvas.getContext('2d')!,gradient=shadowContext.createRadialGradient(128,32,2,128,32,125);
  gradient.addColorStop(0,'rgba(176,55,90,.18)');gradient.addColorStop(.55,'rgba(176,55,90,.08)');gradient.addColorStop(1,'rgba(176,55,90,0)');
  shadowContext.fillStyle=gradient;shadowContext.fillRect(0,0,256,64);
  const shadowTexture=new THREE.CanvasTexture(shadowCanvas);shadowTexture.colorSpace=THREE.SRGBColorSpace;textures.push(shadowTexture);
  const shadowMaterial=new THREE.MeshBasicMaterial({map:shadowTexture,transparent:true,depthWrite:false,toneMapped:false});materials.push(shadowMaterial);
  const shadowGeometry=new THREE.PlaneGeometry(4.3,.4);geometries.push(shadowGeometry);
  const softShadow=new THREE.Mesh(shadowGeometry,shadowMaterial);softShadow.position.set(0,-1.64,-.9);group.add(softShadow);
  return {
    group,picks,items,ready:Promise.all(pending),
    dispose(){disposed=true;geometries.forEach(geometry=>geometry.dispose());materials.forEach(material=>material.dispose());textures.forEach(texture=>texture.dispose());},
  };
}
