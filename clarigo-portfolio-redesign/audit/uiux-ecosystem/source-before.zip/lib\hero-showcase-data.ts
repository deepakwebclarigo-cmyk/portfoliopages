// Screen rectangles were checked against the owning project's original artwork.
// UVs remove the supplied device bezel; original files are never changed.
export const heroShowcaseAssets = [
  { name: 'Beliri', kind: 'web', src: '/images/projects/beliri-87bd5f5b64.webp', width: 1495, height: 2200, crop: { x: 114, y: 230, width: 1266, height: 1699 } },
  { name: 'ParaNest', kind: 'web', src: '/images/projects/paranest-artwork-c7a5793af5.webp', width: 1495, height: 2200, crop: { x: 112, y: 230, width: 1274, height: 1697 } },
  { name: 'HabitStride', kind: 'mobile', src: '/images/projects/app-habitstride-artwork-d31d050563.webp', width: 376, height: 813, crop: { x: 23, y: 20, width: 330, height: 714 } },
] as const;
