// Original decorative vector artwork, rather than an invented product screenshot.
export default function HeroSculpture() {
  return <div className="heroSculpture"><div className="heroSculptureFloat">
    <svg viewBox="0 0 500 460" fill="none" focusable="false" aria-hidden="true">
      <defs>
        <linearGradient id="ribbon-back" x1="97" y1="120" x2="369" y2="321" gradientUnits="userSpaceOnUse">
          <stop stopColor="#fdfbff" /><stop offset=".29" stopColor="#dedaff" /><stop offset=".61" stopColor="#f5c8d2" /><stop offset="1" stopColor="#ea879b" />
        </linearGradient>
        <linearGradient id="ribbon-face" x1="172" y1="155" x2="342" y2="369" gradientUnits="userSpaceOnUse">
          <stop stopColor="#fff6fa" /><stop offset=".3" stopColor="#f8adbd" /><stop offset=".65" stopColor="#f4415a" /><stop offset="1" stopColor="#f185a0" />
        </linearGradient>
        <linearGradient id="ribbon-edge" x1="121" y1="157" x2="304" y2="354" gradientUnits="userSpaceOnUse">
          <stop stopColor="white" stopOpacity=".9" /><stop offset=".55" stopColor="white" stopOpacity=".24" /><stop offset="1" stopColor="white" stopOpacity=".06" />
        </linearGradient>
        <linearGradient id="ribbon-fold" x1="306" y1="253" x2="335" y2="312" gradientUnits="userSpaceOnUse">
          <stop stopColor="#df2c49" stopOpacity=".65" /><stop offset="1" stopColor="#f5b8c6" stopOpacity=".1" />
        </linearGradient>
      </defs>
      <g className="heroRibbonBack">
        <path d="M112 333C50 270 62 153 147 100C232 45 366 66 403 148C434 218 380 294 310 321L280 264C326 245 360 203 344 171C320 122 239 109 181 145C127 180 120 253 158 290L112 333Z" fill="url(#ribbon-back)" />
        <path d="M113 330C53 268 66 155 149 103C231 50 362 68 399 150" stroke="url(#ribbon-edge)" strokeWidth="1.5" />
      </g>
      <g className="heroRibbonFront">
        <path d="M158 290C184 323 256 331 296 301C331 275 329 222 303 193C276 163 226 163 208 187C186 216 218 248 249 243L254 301C179 312 123 241 154 178C187 109 287 109 345 165C401 218 404 302 347 347C281 400 163 386 112 333L158 290Z" fill="url(#ribbon-face)" />
        <path d="M158 291C185 325 257 333 298 303C334 276 332 223 305 192C277 161 225 161 206 186" stroke="url(#ribbon-edge)" strokeWidth="1.5" />
        <path d="M310 321L280 264C296 257 310 249 321 239C334 260 326 297 310 321Z" fill="url(#ribbon-fold)" opacity=".55" />
      </g>
    </svg>
  </div></div>;
}
